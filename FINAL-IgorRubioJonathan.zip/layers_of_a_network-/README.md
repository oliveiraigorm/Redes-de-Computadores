# layers_of_a_network-
Practical work done for the discipline "networks" in the course of computer engineering
<ul>
  <li>Physical layer - Python</li>
  <li>Transport layer - PHP</li>
  <li>Network layer - Javascript</li>
  <li>Application layer - Lua</li>
</ul>
