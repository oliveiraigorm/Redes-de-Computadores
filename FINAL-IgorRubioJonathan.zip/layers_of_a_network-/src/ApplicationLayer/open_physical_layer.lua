os.execute("python PhysicalLayer/server.py")
