function load_table()
	return {
		['192.168.10.1'] = 'pc_john',
		['192.168.10.2'] = 'pc_rubio',
		['192.168.10.3'] = 'pc_igor',
		['192.168.10.4'] = 'nada_aqui'
	}
end
