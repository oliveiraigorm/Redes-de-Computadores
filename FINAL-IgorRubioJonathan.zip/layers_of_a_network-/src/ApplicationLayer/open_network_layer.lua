os.execute("node NetworkLayer/gateway.js")
os.execute("node NetworkLayer/PC1.js")
os.execute("node NetworkLayer/PC2.js")
