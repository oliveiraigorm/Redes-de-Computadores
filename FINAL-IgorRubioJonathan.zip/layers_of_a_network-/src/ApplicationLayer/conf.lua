-- Configuration
function love.conf(t)
	t.title = "DNS Server"     -- The title of the window the game is in (string)
	t.window.width = 900
	t.window.height = 600

	-- For Windows debugging
	t.console = true
end
