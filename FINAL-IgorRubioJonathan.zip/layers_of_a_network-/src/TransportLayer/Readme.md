#References
[About transport layer](http://www.lsi.usp.br/~acacio/CCNA_Cap11Mod01.pdf)